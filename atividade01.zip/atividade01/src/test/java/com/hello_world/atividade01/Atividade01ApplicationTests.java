package com.hello_world.atividade01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
